import json, hashlib, random, collections, pathlib, csv
ROOT=pathlib.Path(__file__).parent
# Synthetic fixture: each row is an independently specified project policy, not general engineering advice.
# A concept|decorators ; O concept ; phase ; modality ; T concept|decorators ; directive ; A query alias ; T query alias ; natural decision query ; alternate directed O (optional)
# Decorators are flat, composed before embedding. No hierarchy is encoded.
DATA = '''
@reporting|report|Which project rules govern transactional consistency for the different report types?
report|month-end;consistency;+;required;transaction|database;Month-end reports must read transactionally consistent committed data.;period-close financial report;database unit of work;I am selecting the read isolation for the accounting close output. What consistency constraint applies?;must provide consistency for
report|dashboard;consistency;-;not_required;transaction|database;Live operational dashboards need not require transactional consistency.;live operations dashboard;database unit of work;Can I use lagging reads for the live dashboard rather than a consistent transaction snapshot?;need not provide consistency for
report|regulatory;consistency;++;strict_required;transaction|database;Regulatory reports must use a strictly consistent transaction snapshot.;statutory filing report;database unit of work;For statutory reporting, what is the mandatory transaction consistency policy?;must strictly guarantee consistency for
report|provisional;consistency;-;not_required;transaction|database;Provisional reports need not be transactionally consistent.;preliminary results report;database unit of work;For a preliminary report that is explicitly provisional, is transactional consistency mandatory?;need not provide consistency for
report|reconciliation;consistency;+;required;transaction|database;Reconciliation reports require transactional consistency.;ledger matching report;database unit of work;I am implementing ledger matching reports. What consistency requirement applies to reads?;must provide consistency for
report|historical archive;consistency;-;not_required;transaction|database;Historical archive reports need not open a transactionally consistent live snapshot.;archived historical report;database unit of work;When reading archived report data, must the live database snapshot be transactionally consistent?;need not provide consistency for
report|month-end;audit retention;+;required;audit log|report execution;Month-end reports must retain their execution audit log.;period-close financial report;report run audit trail;What execution audit retention is required for the accounting close report?;
report|dashboard;refresh frequency;+;required;cache|dashboard;Live dashboards must refresh their cache at least every five minutes.;live operations dashboard;dashboard read cache;What is the maximum permitted cache refresh interval for the live dashboard?;
@payment|payment|What are the payment-specific idempotency requirements across these payment flows?
payment|authorization;idempotency;+;required;request|payment API;Payment authorization requests must be idempotent.;funds authorization;payment service request;I am adding retries to the authorization API. What duplicate-request rule applies?;must support idempotency for
payment|capture;idempotency;++;strict_required;request|payment API;Payment capture requests must be strictly idempotent.;funds capture;payment service request;When capturing an authorized payment, what is the strict duplicate-request requirement?;must strictly support idempotency for
payment|refund;idempotency;+;required;request|payment API;Refund requests must be idempotent.;payment reimbursement;payment service request;If a refund call times out and is retried, what idempotency rule applies?;must support idempotency for
payment|status inquiry;idempotency;-;not_required;request|payment API;Payment status inquiries need not supply an idempotency key.;payment status lookup;payment service request;Does a read-only payment status enquiry need an idempotency key?;need not require an idempotency key for
payment|sandbox simulation;idempotency;-;not_required;request|payment API;Sandbox payment simulations need not supply an idempotency key.;test-mode simulated payment;payment service request;Is an idempotency key mandatory in the sandbox payment simulator?;need not require an idempotency key for
payment|payout;idempotency;++;strict_required;request|payment API;Payout requests must be strictly idempotent.;merchant disbursement;payment service request;For merchant disbursements, what is the strict duplicate-request policy?;must strictly support idempotency for
payment|refund;authorization;+;required;role|finance approver;Refunds above the configured threshold require finance approver authorization.;payment reimbursement;finance approval role;Who must authorize an above-threshold refund?;
payment|capture;timeout;+;required;connection|payment gateway;Payment capture must use a ten-second gateway timeout.;funds capture;gateway network connection;What gateway timeout is required for payment capture?;
@storage|storage|What encryption-at-rest policies apply to the different storage scopes?
storage|customer records;encryption;+;required;data|at rest;Customer record storage must encrypt data at rest.;customer information store;persisted data;Do stored customer records require at-rest encryption?;must be encrypted in
storage|payment records;encryption;++;strict_required;data|at rest;Payment record storage must enforce encryption at rest with managed keys.;payment information store;persisted data;What strict at-rest encryption rule applies to stored payment records?;must be encrypted with managed keys in
storage|public assets;encryption;-;not_required;data|at rest;Public asset storage need not encrypt data at rest.;public static asset store;persisted data;Is at-rest encryption mandatory for public static asset storage?;need not be encrypted in
storage|synthetic test fixtures;encryption;-;not_required;data|at rest;Storage for synthetic test fixtures need not encrypt data at rest.;generated test fixture store;persisted data;Must generated test fixtures be encrypted on disk?;need not be encrypted in
storage|production backups;encryption;++;strict_required;data|at rest;Production backup storage must enforce encryption at rest with managed keys.;production backup repository;persisted data;What strict at-rest encryption policy applies to production backups?;must be encrypted with managed keys in
storage|internal documents;encryption;+;required;data|at rest;Internal document storage must encrypt data at rest.;internal document repository;persisted data;What at-rest encryption requirement applies to internal documents?;must be encrypted in
storage|customer records;retention;+;required;data|customer records;Customer records must be retained for seven years in this synthetic project.;customer information store;customer record data;How long must customer records be retained under the project rule?;
storage|production backups;immutability;+;required;backup|production;Production backups must be immutable for thirty days.;production backup repository;production backup copy;What is the immutability period for production backups?;
@cache|cache|What staleness allowances apply to the various caches?
cache|product catalog;staleness;+;permitted;read|cached;Product catalog caches may serve stale reads for up to five minutes.;product listing cache;cached read operation;How much stale data may the product listing cache serve?;may be stale for up to five minutes in
cache|inventory availability;staleness;-;prohibited;read|cached;Inventory availability caches must not serve stale reads for checkout.;stock availability cache;cached read operation;Can checkout use stale stock-availability cache values?;must not be stale in
cache|marketing content;staleness;++;permitted;read|cached;Marketing content caches may serve stale reads for up to one hour.;promotional content cache;cached read operation;What staleness allowance applies to cached promotional content?;may be stale for up to one hour in
cache|account balance;staleness;-;prohibited;read|cached;Account balance caches must not serve stale reads for settlement.;account funds cache;cached read operation;Are stale account-balance reads allowed during settlement?;must not be stale in
cache|search suggestions;staleness;+;permitted;read|cached;Search suggestion caches may serve stale reads for up to ten minutes.;autocomplete cache;cached read operation;What is the permitted staleness of autocomplete cache results?;may be stale for up to ten minutes in
cache|feature flags;staleness;-;prohibited;read|cached;Feature flag caches must not serve stale reads for kill switches.;feature toggle cache;cached read operation;May a kill switch consult stale cached feature flags?;must not be stale in
cache|product catalog;invalidation;+;required;event|product update;Catalog caches must invalidate on a product update event.;product listing cache;product change event;What event must invalidate the product catalog cache?;
cache|feature flags;fallback;+;required;configuration|safe defaults;Feature flag caches must fall back to safe defaults if unavailable.;feature toggle cache;safe default settings;What fallback is required when the feature flag cache is unavailable?;
@api|endpoint|Which endpoint-specific authentication policies are defined?
endpoint|public health;authentication;-;not_required;credential|API;The public health endpoint need not require API credentials.;public health probe;API access credential;Does the public liveness endpoint require a credential?;need not be supplied to
endpoint|admin management;authentication;++;strict_required;credential|API;Admin management endpoints must require authenticated API credentials and MFA.;administrative control API;API access credential;What authentication requirement applies to administrative management calls?;must be authenticated with MFA for
endpoint|customer profile;authentication;+;required;credential|API;Customer profile endpoints must require authenticated API credentials.;user profile API;API access credential;Must a user profile API caller authenticate?;must be authenticated for
endpoint|public catalog;authentication;-;not_required;credential|API;Public catalog endpoints need not require API credentials.;public product listing API;API access credential;Does the public product listing API need credentials?;need not be supplied to
endpoint|billing;authentication;++;strict_required;credential|API;Billing endpoints must require authenticated API credentials and MFA.;billing service API;API access credential;What strict authentication rule applies to billing calls?;must be authenticated with MFA for
endpoint|internal diagnostics;authentication;+;required;credential|API;Internal diagnostics endpoints must require authenticated API credentials.;internal diagnostic API;API access credential;Do internal diagnostics calls need authenticated credentials?;must be authenticated for
endpoint|customer profile;authorization;+;required;role|profile owner;Customer profile endpoints must authorize access against profile ownership.;user profile API;profile owner role;What ownership authorization applies to profile API access?;
endpoint|public catalog;rate limiting;+;required;request|HTTP;Public catalog endpoints must rate-limit HTTP requests to 100 per minute per IP.;public product listing API;HTTP service request;What per-IP request limit applies to the public catalog?;
@events|event|What delivery semantics apply to the event classes?
event|financial posting;delivery guarantee;++;strict_required;message|broker;Financial posting events must use at-least-once delivery with deduplication.;ledger posting event;broker message;What delivery guarantee is required for ledger posting messages?;must provide at-least-once delivery with deduplication for
event|telemetry;delivery guarantee;-;not_required;message|broker;Telemetry events need not have guaranteed delivery.;observability metric event;broker message;Do telemetry messages need guaranteed delivery?;need not guarantee delivery for
event|order fulfillment;delivery guarantee;+;required;message|broker;Order fulfillment events must use at-least-once delivery.;order dispatch event;broker message;Which delivery guarantee applies to order fulfillment messages?;must provide at-least-once delivery for
event|presence heartbeat;delivery guarantee;-;not_required;message|broker;Presence heartbeat events need not have guaranteed delivery.;online presence ping;broker message;Must an online presence heartbeat be guaranteed delivery?;need not guarantee delivery for
event|inventory adjustment;delivery guarantee;+;required;message|broker;Inventory adjustment events must use at-least-once delivery.;stock adjustment event;broker message;What delivery guarantee applies to stock adjustment messages?;must provide at-least-once delivery for
event|audit record;delivery guarantee;++;strict_required;message|broker;Audit record events must use at-least-once delivery with deduplication.;audit trail event;broker message;What strict delivery semantics apply to audit trail messages?;must provide at-least-once delivery with deduplication for
event|financial posting;ordering;+;required;message|broker;Financial posting events must preserve message order per ledger account.;ledger posting event;broker message;What per-account ordering must ledger posting messages preserve?;
event|telemetry;batching;+;permitted;message|broker;Telemetry events may batch broker messages for up to thirty seconds.;observability metric event;broker message;How long may telemetry messages be batched?;
@deployment|deployment|Which approval requirements apply to the deployment environments?
deployment|production;approval;++;strict_required;change|release;Production deployments require two independent release approvals.;live environment rollout;release change;How many independent approvals are needed for a production rollout?;must have two independent approvals for
deployment|developer sandbox;approval;-;not_required;change|release;Developer sandbox deployments need not have release approval.;developer test rollout;release change;Is release approval mandatory for a personal developer sandbox rollout?;need not have approval for
deployment|staging;approval;+;required;change|release;Staging deployments require one release approval.;preproduction rollout;release change;How many approvals are needed to deploy to staging?;must have one approval for
deployment|preview;approval;-;not_required;change|release;Preview deployments need not have release approval.;temporary preview environment rollout;release change;Does a temporary preview deployment need release approval?;need not have approval for
deployment|regulated production;approval;++;strict_required;change|release;Regulated production deployments require three independent release approvals.;regulated live environment rollout;release change;How many approvals does a regulated production release require?;must have three independent approvals for
deployment|shared integration;approval;+;required;change|release;Shared integration deployments require one release approval.;shared integration environment rollout;release change;What approval count applies to a shared integration rollout?;must have one approval for
deployment|production;rollback;+;required;artifact|release;Production deployments must retain the preceding release artifact for rollback.;live environment rollout;release build artifact;Which artifact must a live deployment retain for rollback?;
deployment|preview;expiration;+;required;environment|preview;Preview deployments must expire after forty-eight hours.;temporary preview environment rollout;temporary preview environment;What expiration duration applies to a preview deployment?;
@logging|log|Which log classes permit or prohibit recording sensitive payload fields?
log|payment;payload recording;-;prohibited;data|sensitive payload;Payment logs must not record sensitive payload fields.;payment processing log;confidential request content;May a payment processing log include sensitive payload fields?;must not be recorded in
log|debug sandbox;payload recording;+;permitted;data|sensitive payload;Debug sandbox logs may record synthetic sensitive payload fields only.;sandbox debugging log;confidential request content;Can sandbox debug logs include synthetic sensitive payload values?;may be recorded only if synthetic in
log|authentication;payload recording;-;prohibited;data|sensitive payload;Authentication logs must not record sensitive payload fields.;login service log;confidential request content;May login service logs contain sensitive payload fields?;must not be recorded in
log|security incident;payload recording;+;permitted;data|sensitive payload;Security incident logs may record sensitive payload fields only in the restricted incident vault.;security incident investigation log;confidential request content;Where may incident investigation logs record sensitive payload fields?;may be recorded only in a restricted vault for
log|customer support;payload recording;-;prohibited;data|sensitive payload;Customer support logs must not record sensitive payload fields.;support interaction log;confidential request content;Can customer support logs record sensitive payload fields?;must not be recorded in
log|approved forensic;payload recording;+;permitted;data|sensitive payload;Approved forensic logs may record sensitive payload fields in the isolated forensic store.;approved forensic analysis log;confidential request content;What condition permits sensitive payload capture in approved forensic logs?;may be recorded in an isolated forensic store for
log|payment;retention;+;required;data|log entries;Payment logs must retain entries for ninety days.;payment processing log;stored log record;What retention duration applies to payment processing logs?;
log|authentication;redaction;+;required;data|session identifiers;Authentication logs must redact session identifiers.;login service log;session identifier data;What redaction is required for session identifiers in login logs?;
@concurrency|job|Which concurrency controls apply to the job classes?
job|ledger settlement;concurrency control;++;strict_required;lock|distributed;Ledger settlement jobs must acquire an exclusive distributed lock.;ledger closing task;distributed execution lock;What distributed locking is mandatory for the ledger settlement job?;must be acquired exclusively by
job|thumbnail rendering;concurrency control;-;not_required;lock|distributed;Thumbnail rendering jobs need not acquire a distributed lock.;image thumbnail task;distributed execution lock;Does thumbnail rendering need distributed locking?;need not be acquired by
job|invoice numbering;concurrency control;+;required;lock|distributed;Invoice numbering jobs must acquire a distributed lock per numbering series.;invoice sequence allocation task;distributed execution lock;What distributed locking scope applies to invoice sequence allocation?;must be acquired per numbering series by
job|search reindex;concurrency control;-;not_required;lock|distributed;Search reindex jobs need not acquire a distributed lock.;search indexing task;distributed execution lock;Is distributed locking mandatory for search reindexing?;need not be acquired by
job|inventory reservation;concurrency control;++;strict_required;lock|distributed;Inventory reservation jobs must acquire an exclusive distributed lock per SKU.;stock reservation task;distributed execution lock;What exclusive distributed locking applies to stock reservation jobs?;must be acquired exclusively per SKU by
job|scheduled export;concurrency control;+;required;lock|distributed;Scheduled export jobs must acquire a distributed lock per export destination.;scheduled data export task;distributed execution lock;What lock scope is required for scheduled data exports?;must be acquired per destination by
job|ledger settlement;retry;-;prohibited;execution|automatic retry;Ledger settlement jobs must not automatically retry after an unknown commit result.;ledger closing task;automatic execution retry;May ledger settlement automatically retry following an unknown commit outcome?;
job|search reindex;retry;+;permitted;execution|automatic retry;Search reindex jobs may automatically retry failed executions.;search indexing task;automatic execution retry;May failed search reindex executions automatically retry?;
@schema|schema|Which schema migration compatibility requirements apply across the different data interfaces?
schema|public API;backward compatibility;++;strict_required;migration|schema change;Public API schemas must preserve backward compatibility for two major versions.;external API contract;schema change migration;What backward compatibility window applies to public API schema changes?;must preserve two major versions of backward compatibility for
schema|private prototype;backward compatibility;-;not_required;migration|schema change;Private prototype schemas need not preserve backward compatibility.;private experimental schema;schema change migration;Must a private prototype migration remain backward compatible?;need not preserve backward compatibility for
schema|billing event;backward compatibility;+;required;migration|schema change;Billing event schemas must preserve backward compatibility.;billing event contract;schema change migration;Do billing event migrations need backward compatibility?;must preserve backward compatibility for
schema|ephemeral test;backward compatibility;-;not_required;migration|schema change;Ephemeral test schemas need not preserve backward compatibility.;temporary test schema;schema change migration;Is backward compatibility required for temporary test schema changes?;need not preserve backward compatibility for
schema|partner API;backward compatibility;++;strict_required;migration|schema change;Partner API schemas must preserve backward compatibility for twelve months.;partner-facing API contract;schema change migration;What compatibility period applies to partner API schema changes?;must preserve twelve months of backward compatibility for
schema|shared data warehouse;backward compatibility;+;required;migration|schema change;Shared data warehouse schemas must preserve backward compatibility.;shared analytics schema;schema change migration;Must shared warehouse schema migrations preserve backward compatibility?;must preserve backward compatibility for
schema|public API;versioning;+;required;contract|API version;Public API schemas must increment the major API version for breaking changes.;external API contract;API version contract;How must a breaking public API change be versioned?;
schema|billing event;validation;+;required;pipeline|CI;Billing event schemas must pass schema compatibility validation in CI.;billing event contract;continuous integration pipeline;Which pipeline must validate billing event schema compatibility?;
@testing|test|Which test categories may or may not contact external network services?
test|unit;network access;-;prohibited;service|external network;Unit tests must not contact external network services.;isolated unit test;external network service;Can an isolated unit test call a real remote service?;must not be contacted by
test|integration sandbox;network access;+;permitted;service|external network;Sandbox integration tests may contact allowlisted external network services.;sandbox integration test;external network service;Can a sandbox integration test call an allowlisted remote service?;may be contacted if allowlisted by
test|deterministic regression;network access;-;prohibited;service|external network;Deterministic regression tests must not contact external network services.;deterministic regression suite;external network service;Can the deterministic regression suite call external services?;must not be contacted by
test|end-to-end staging;network access;+;permitted;service|external network;Staging end-to-end tests may contact approved external network services.;staging full-flow test;external network service;May staging end-to-end tests call approved external systems?;may be contacted if approved by
test|offline acceptance;network access;-;prohibited;service|external network;Offline acceptance tests must not contact external network services.;offline acceptance suite;external network service;Can offline acceptance tests make remote network calls?;must not be contacted by
test|contract provider;network access;+;permitted;service|external network;Provider contract tests may contact the designated external sandbox service.;provider contract verification;external network service;Which external service may provider contract verification contact?;may be contacted only when designated for
test|unit;execution time;+;required;pipeline|CI;Unit tests must complete within two minutes in CI.;isolated unit test;continuous integration pipeline;What time budget applies to unit tests in CI?;
test|end-to-end staging;credential isolation;+;required;credential|test;Staging end-to-end tests must use isolated test credentials.;staging full-flow test;test access credential;What credential isolation rule applies to staging full-flow tests?;
@access|role|Which role-specific write permissions apply to production records?
role|finance operator;write access;+;permitted;record|production;Finance operators may write production records only within their assigned ledger.;finance operations role;live production record;May a finance operator modify a live record in an assigned ledger?;may be written only within assigned ledger by
role|finance auditor;write access;-;prohibited;record|production;Finance auditors must not write production records.;finance audit role;live production record;Can a finance auditor modify production records?;must not be written by
role|customer support;write access;+;permitted;record|production;Customer support may write production records only for approved profile corrections.;support agent role;live production record;When may a support agent modify live production records?;may be written only for approved profile corrections by
role|external reviewer;write access;-;prohibited;record|production;External reviewers must not write production records.;external review role;live production record;Can an external reviewer modify production records?;must not be written by
role|incident responder;write access;+;permitted;record|production;Incident responders may write production records only with an approved emergency ticket.;incident response role;live production record;What approval is needed for incident responders to modify production records?;may be written only with approved emergency ticket by
role|analytics reader;write access;-;prohibited;record|production;Analytics readers must not write production records.;analytics read-only role;live production record;May an analytics reader update production records?;must not be written by
role|finance operator;audit logging;+;required;log|access audit;Finance operator writes must produce access audit logs.;finance operations role;access audit trail;What audit logging is required when finance operators write records?;
role|incident responder;session duration;+;required;credential|emergency access;Incident responder emergency credentials must expire after one hour.;incident response role;emergency access credential;How long may emergency incident responder credentials remain valid?;
@export|export|Which export variants require compression of their output files?
export|monthly|financial;compression;+;required;file|export output;Monthly financial exports must compress their output files.;monthly finance data extract;export output file;Must the monthly finance extract compress its output?;must be compressed for
export|monthly|operational;compression;-;not_required;file|export output;Monthly operational exports need not compress their output files.;monthly operations data extract;export output file;Is compression required for the monthly operations extract?;need not be compressed for
export|daily|financial;compression;++;strict_required;file|export output;Daily financial exports must use gzip compression on all output files.;daily finance data extract;export output file;What strict compression format is required for the daily finance extract?;must be gzip compressed for
export|daily|operational;compression;-;not_required;file|export output;Daily operational exports need not compress output files.;daily operations data extract;export output file;Must the daily operations extract compress its output?;need not be compressed for
export|monthly|financial|consolidated;compression;++;strict_required;file|export output;Consolidated monthly financial exports must use gzip compression on all output files.;consolidated monthly finance extract;export output file;What compression format is mandatory for the consolidated monthly finance extract?;must be gzip compressed for
export|monthly|financial|provisional;compression;-;not_required;file|export output;Provisional monthly financial exports need not compress their output files.;preliminary monthly finance extract;export output file;Does the explicitly provisional monthly finance extract need compression?;need not be compressed for
export|daily|financial;checksum;+;required;file|export output;Daily financial exports must include an SHA-256 checksum for each output file.;daily finance data extract;export output file;What checksum is required for daily finance extract files?;
export|monthly|operational;partitioning;+;required;file|export output;Monthly operational exports must partition output files by business unit.;monthly operations data extract;export output file;What file partitioning rule applies to monthly operations exports?;
@notification|notification|Which notification variants may contain the full message body?
notification|email|external;body inclusion;-;prohibited;message|full body;External email notifications must not include the full message body.;external email alert;complete message content;May an email alert to external recipients include the complete message content?;must not be included in
notification|email|internal;body inclusion;+;permitted;message|full body;Internal email notifications may include the full message body.;internal email alert;complete message content;Is the complete message content permitted in internal email alerts?;may be included in
notification|push|external;body inclusion;-;prohibited;message|full body;External push notifications must not include the full message body.;external mobile push alert;complete message content;May external mobile push alerts include the complete message content?;must not be included in
notification|push|internal;body inclusion;+;permitted;message|full body;Internal push notifications may include the full message body.;internal mobile push alert;complete message content;Can internal mobile push alerts include the complete message content?;may be included in
notification|email|internal|confidential;body inclusion;-;prohibited;message|full body;Confidential internal email notifications must not include the full message body.;confidential internal email alert;complete message content;Can a confidential internal email alert include the complete message content?;must not be included in
notification|email|internal|approved forensic;body inclusion;+;permitted;message|full body;Approved forensic internal email notifications may include the full message body.;approved forensic internal email alert;complete message content;May an approved forensic internal email alert include the complete message content?;may be included in
notification|email|external;delivery deadline;+;required;message|notification;External email notifications must be submitted for delivery within five minutes.;external email alert;notification message;What submission deadline applies to external email alerts?;
notification|push|internal;retry;+;permitted;message|notification;Internal push notifications may retry failed delivery twice.;internal mobile push alert;notification message;How many delivery retries may internal push alerts perform?;
'''

entities={}; operations={}; rules={}; edges={}; queries=[]; families={}; entity_aliases=collections.defaultdict(set)
MOD={'required':'is required','strict_required':'must be strictly enforced','not_required':'is not required','prohibited':'is prohibited','permitted':'is permitted'}
PH={'+':1,'++':2,'-':-1}
def uid(prefix,*parts): return prefix+'_'+hashlib.sha256('|'.join(parts).encode()).hexdigest()[:12]
def ent(s, alias=None):
    c,*ds=s.split('|'); d=[x.strip() for x in ds if x.strip()]; k=uid('e',c,*d)
    entities[k]={'id':k,'concept':c,'decorators':d,'contextual_text':' '.join(d+[c])}
    if alias: entity_aliases[k].add(alias)
    return k
def op(c,p,m, phrase=None):
    txt=phrase or (f'{c} {MOD[m]}'+(' to a greater degree' if p=='++' and m=='permitted' else ''))
    k=uid('o',c,p,m,txt)
    operations[k]={'id':k,'concept':c,'phase':PH[p],'phase_symbol':p,'modality':m,'contextual_text':txt}
    return k
def edge(a,o,t,r):
    k=uid('g',a,o,t,r); edges[k]={'id':k,'source_id':a,'operation_id':o,'target_id':t,'rule_id':r}; return k
def query(task,split,f,text,pos,hard=(),**kw):
    pos=sorted(set(pos)); hard=sorted(set(hard)-set(pos)); assert pos
    qid=uid('q',task,split,f,text,str(kw.get('view','')),str(kw.get('source_rule_id','')))
    queries.append(dict(id=qid,task=task,split=split,family=f,query=text,positive_ids=pos,hard_negative_ids=hard,**kw))

for line in DATA.strip().splitlines():
    if line.startswith('@'):
        fam,base,broad=line[1:].split('|'); families[fam]={'base':base,'broad':broad,'rows':[]}; continue
    a,oc,p,m,t,txt,aa,ta,nq,reverse=line.split(';')
    ai,ti=ent(a,aa),ent(t,ta); oi=op(oc,p,m)
    ri=uid('r',fam,txt); gi=edge(ai,oi,ti,ri)
    alt=[]
    if reverse: alt.append(edge(ti,op(oc,p,m,reverse),ai,ri))
    rules[ri]={'id':ri,'family':fam,'directive':txt,'modality':m,'phase':PH[p],'canonical_edge_id':gi,'alternate_edge_ids':alt}
    families[fam]['rows'].append((ri,ai,oi,ti,aa,ta,nq,oc,p,m))

# Split by entire family: model selection cannot use test-family query labels. Corpus is shared by design.
dev={'reporting','cache','events','schema','export'}
for f,info in families.items():
    split='dev' if f in dev else 'test'; rows=info['rows']; rids=[r[0] for r in rows]
    scopes=sorted({r[1] for r in rows}); targets=sorted({r[3] for r in rows})
    for ri,a,o,t,aa,ta,nq,oc,p,m in rows:
        # Same query has a natural-language view and an oracle structured view; never use oracle fields in NL track.
        qstruct={'attention':{'concept':entities[a]['concept'],'decorators':entities[a]['decorators'],'text':aa},'operation':{'concept':oc,'phase':None,'modality':None,'text':oc},'target':{'concept':entities[t]['concept'],'decorators':entities[t]['decorators'],'text':ta}}
        query('relationship',split,f,nq,[ri],rids,view='natural_decision',source_rule_id=ri,oracle_aotd=qstruct,positive_edge_ids=[rules[ri]['canonical_edge_id'],*rules[ri]['alternate_edge_ids']])
        # A neutral operation query must recover scope-specific rules without assuming the answer's polarity.
        query('relationship',split,f,f'{aa}: what is the project policy on {oc} for {ta}?',[ri],rids,view='structured_paraphrase',source_rule_id=ri,oracle_aotd=qstruct,positive_edge_ids=[rules[ri]['canonical_edge_id'],*rules[ri]['alternate_edge_ids']])
        # Explicit opposite-direction prompt for each valid authored alternate, gold by canonical rule.
        if rules[ri]['alternate_edge_ids']:
            swapped={'attention':qstruct['target'],'operation':qstruct['operation'],'target':qstruct['attention']}
            query('relationship',split,f,f'For {ta}, what {oc} constraint applies specifically to {aa}?',[ri],rids,view='alternate_attention',source_rule_id=ri,oracle_aotd=swapped,positive_edge_ids=rules[ri]['alternate_edge_ids'])
    # Broad scope queries deliberately retrieve both positive and negative phases for the main operation.
    main=rows[0][7]; mainrows=[r for r in rows if r[7]==main]
    query('relationship',split,f,info['broad'],[r[0] for r in mainrows],rids,view='broad_scope',oracle_aotd={'attention':{'concept':info['base'],'decorators':[],'text':info['base']},'operation':{'concept':main,'phase':None,'modality':None,'text':main},'target':{'concept':entities[mainrows[0][3]]['concept'],'decorators':entities[mainrows[0][3]]['decorators'],'text':mainrows[0][5]}})
    # Entity-only queries: one shared population, not A and T indices.
    for a in scopes:
        for alias in sorted(entity_aliases[a]):
            query('entity',split,f,alias,[a],scopes+targets,view='decorated_entity',oracle_entity={'concept':entities[a]['concept'],'decorators':entities[a]['decorators']})
    query('entity',split,f,info['base'],[k for k,v in entities.items() if v['concept']==info['base']],targets,view='broad_entity',oracle_entity={'concept':info['base'],'decorators':[]})
    # Operation relevance vs exact modality are distinct tasks. Group all direction-specific formulations by underlying concept.
    for oc in sorted({r[7] for r in rows}):
        positives=[k for k,v in operations.items() if v['concept']==oc]
        near={'consistency':{'concurrency control','backward compatibility','ordering'},'idempotency':{'retry','delivery guarantee'},'authentication':{'authorization','credential isolation'},'authorization':{'authentication','write access'},'encryption':{'redaction','payload recording'},'delivery guarantee':{'ordering','retry'},'retry':{'idempotency','delivery guarantee'},'audit logging':{'audit retention','retention'},'retention':{'audit retention','immutability'},'write access':{'authorization','authentication'},'compression':{'partitioning'},'body inclusion':{'payload recording','redaction'}}
        nearby={r[7] for r in rows if r[7]!=oc}|near.get(oc,set())
        negatives=[k for k,v in operations.items() if v['concept'] in nearby]
        query('operation_topic',split,f,f'{oc} policy',positives,negatives,view='polarity_neutral',oracle_operation={'concept':oc,'phase':None,'modality':None})
        for p,m in sorted({(r[8],r[9]) for r in rows if r[7]==oc}):
            exact=[k for k,v in operations.items() if v['concept']==oc and v['phase']==PH[p] and v['modality']==m]
            opposite=[k for k in positives if k not in exact]
            query('operation_modality',split,f,f'{oc} {MOD[m]}'+(' (strongest level)' if p=='++' else ''),exact,opposite,view='phase_specific',oracle_operation={'concept':oc,'phase':PH[p],'modality':m})

# Multi-decorator partial-match probes. An unspecified decorator is not a negative.
for f,required in [('export',['monthly']),('export',['monthly','financial']),('export',['financial']),('notification',['internal']),('notification',['email','internal']),('notification',['external','push'])]:
    base=families[f]['base']; cand=[k for k,v in entities.items() if v['concept']==base]
    pos=[k for k in cand if set(required)<=set(entities[k]['decorators'])]
    query('entity','dev' if f in dev else 'test',f,'all '+' '.join(required+[base])+' variants',pos,cand,view='partial_decorators',oracle_entity={'concept':base,'decorators':required})
# Target-only aliases, still searched against the same flat entity index.
# Assign each query alias to its first family; no duplicate entity query text across splits.
seen_entity_text={q['query'].casefold() for q in queries if q['task']=='entity'}
for f,info in families.items():
    split='dev' if f in dev else 'test'
    for t in sorted({r[3] for r in info['rows']}):
        for alias in sorted(entity_aliases[t]):
            if alias.casefold() in seen_entity_text: continue
            seen_entity_text.add(alias.casefold())
            hard=[k for k,v in entities.items() if v['concept']==entities[t]['concept'] and k!=t]
            query('entity',split,f,alias,[t],hard,view='target_origin_alias',oracle_entity={'concept':entities[t]['concept'],'decorators':entities[t]['decorators']})

# Standalone path probes: explicit directed dependencies, no claim of transitive semantic inference.
# Each scenario has two valid forward edges, a same-operation sibling, a distinct-operation branch, and an incoming edge.
PATHS=[
('path_checkout','checkout service','inventory reservation service','stock ledger','notification service','checkout audit log','external gateway'),
('path_close','financial close workflow','settlement engine','committed transaction store','dashboard renderer','close metrics log','close scheduler'),
('path_ingest','invoice ingestion pipeline','document classifier','OCR result store','email notification service','ingestion trace','upload gateway'),
('path_release','release controller','deployment verifier','artifact registry','release announcement service','deployment audit record','CI orchestrator'),
('path_search','search API','query coordinator','index shard service','suggestion cache','query metrics','API gateway'),
('path_access','profile update API','authorization service','policy store','profile notification service','profile audit record','frontend gateway'),
('path_payout','merchant payout service','bank connector','settlement account store','payout receipt service','payout trace log','payout scheduler'),
('path_claim','claims adjudication workflow','coverage checker','policy record store','claim status notifier','claim decision audit','claim intake service'),
]
path_cases=[]
for i,(f,a,b,c,d,e,inc) in enumerate(PATHS):
    # A same-O sibling IS a valid activated relationship, not a hard negative for O-only propagation.
    # Distinct-op and incoming branches are the actual negatives.
    ids=[ent(x) for x in (a,b,c,d,e,inc)]; ai,bi,ci,di,ei,ii=ids
    dep=op('dependency','+','required','depends on'); audit=op('audit logging','+','required','writes audit records to')
    specs=[(ai,dep,bi,f'{a} depends on {b}.'),(bi,dep,ci,f'{b} depends on {c}.'),(bi,dep,di,f'{b} depends on {d}.'),(bi,audit,ei,f'{b} writes audit records to {e}.'),(ii,dep,ai,f'{inc} depends on {a}.')]
    gs=[]
    for s,o,t,txt in specs:
        r=uid('r',f,txt); g=edge(s,o,t,r); gs.append(g); rules[r]={'id':r,'family':f,'directive':txt,'modality':'required','phase':1,'canonical_edge_id':g,'alternate_edge_ids':[]}
    path_cases.append({'id':uid('p',f),'family':f,'split':'dev' if i<3 else 'test','query':f'While reviewing {a}, retrieve its forward dependency relationships.','seed_entity_id':ai,'oracle_aotd':{'attention':{'concept':a,'decorators':[],'text':a},'operation':{'concept':'dependency','phase':None,'text':'depends on'},'target':None},'positive_edge_ids':gs[:3],'hard_negative_edge_ids':gs[3:],'gold_paths':[[gs[0],gs[1]],[gs[0],gs[2]]],'notes':'Both same-operation branches are gold. Incoming edge is not traversable from seed. No transitive claim is created.'})
# validate
for g in edges.values(): assert g['source_id'] in entities and g['target_id'] in entities and g['operation_id'] in operations and g['rule_id'] in rules
assert len({q['id'] for q in queries})==len(queries)
assert not ({(q['task'],q['query'].casefold()) for q in queries if q['split']=='dev'} & {(q['task'],q['query'].casefold()) for q in queries if q['split']=='test'})
for q in queries:
    pool={'entity':entities,'relationship':rules,'operation_topic':operations,'operation_modality':operations}[q['task']]
    assert all(k in pool for k in q['positive_ids']+q['hard_negative_ids']) and not set(q['positive_ids'])&set(q['hard_negative_ids'])
for p in path_cases:
    for path in p['gold_paths']:
        assert edges[path[0]]['source_id']==p['seed_entity_id']
        assert all(edges[x]['target_id']==edges[y]['source_id'] for x,y in zip(path,path[1:]))
for k,v in entities.items(): v['aliases_for_audit_only']=sorted(entity_aliases[k])
# Keep aliases in a separate audit file rather than corpus to prevent leakage.
aliases=[{'entity_id':k,'aliases':v.pop('aliases_for_audit_only')} for k,v in entities.items() if v['aliases_for_audit_only']]
for v in entities.values(): v.pop('aliases_for_audit_only',None)
def dump(name,rows):
    with (ROOT/name).open('w') as fp:
        for r in rows: fp.write(json.dumps(r,ensure_ascii=False)+'\n')
for name,rows in [('entities.jsonl',entities.values()),('operations.jsonl',operations.values()),('relationships.jsonl',edges.values()),('constraints.jsonl',rules.values()),('queries_dev.jsonl',[q for q in queries if q['split']=='dev']),('queries_test.jsonl',[q for q in queries if q['split']=='test']),('paths_dev.jsonl',[p for p in path_cases if p['split']=='dev']),('paths_test.jsonl',[p for p in path_cases if p['split']=='test']),('aliases_audit_only.jsonl',aliases)]: dump(name,rows)
summary={'entities':len(entities),'operations':len(operations),'relationships':len(edges),'constraints':len(rules),'scope_policy_families':len(families),'path_scenarios':len(path_cases),'queries':len(queries),'query_counts':dict(collections.Counter(q['task']+'/'+q['split'] for q in queries)),'path_counts':dict(collections.Counter(p['split'] for p in path_cases)),'dev_families':sorted(dev),'test_families':sorted(set(families)-dev),'validation':'Referential integrity, unique query IDs, disjoint positive/hard-negative labels, no exact cross-split query text overlap within task, directed path continuity passed.'}
(ROOT/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
