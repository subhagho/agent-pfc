"""Evaluate rankings from any embedding/graph implementation; stdlib only."""
import argparse,json,pathlib,collections,statistics
P=pathlib.Path(__file__).parent
def read(p):
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def main():
    a=argparse.ArgumentParser(); a.add_argument('--split',choices=['dev','test'],required=True); a.add_argument('--predictions',type=pathlib.Path,required=True); a.add_argument('--k',type=int,default=10); args=a.parse_args(); assert args.k>0
    qs=read(P/f'queries_{args.split}.jsonl')
    qs += [dict(q,task='path',view='forward_resonance',positive_ids=q['positive_edge_ids'],hard_negative_ids=q['hard_negative_edge_ids']) for q in read(P/f'paths_{args.split}.jsonl')]
    pools={t:{x['id'] for x in read(P/f'{f}.jsonl')} for t,f in [('entity','entities'),('operation_topic','operations'),('operation_modality','operations'),('relationship','constraints'),('path','relationships')]}
    valid_qids={q['id'] for q in qs}; preds={}
    for row in read(args.predictions):
        qid=row['id']; ranking=row['ranked_ids']; assert qid in valid_qids, f'Unknown query {qid}'; assert qid not in preds, f'Duplicate query {qid}'; assert len(ranking)==len(set(ranking)),f'Duplicate ranked ID {qid}'; preds[qid]=ranking
    groups=collections.defaultdict(list)
    for q in qs:
        full=preds.get(q['id'],[]); assert set(full)<=pools[q['task']],f'Invalid corpus ID for {q["id"]}'
        rank=full[:args.k]; gold=set(q['positive_ids']); hard=set(q['hard_negative_ids']); n=len(set(rank)&gold); first=next((i+1 for i,x in enumerate(full) if x in gold),None); fh=next((i+1 for i,x in enumerate(full) if x in hard),None)
        m={'recall_at_k':n/len(gold),'precision_at_k':n/args.k,'mrr':1/first if first else 0,'full_gold_at_k':float(n==len(gold)),'hard_negative_exposure_at_k':float(bool(hard&set(rank))),'hard_negative_outranks_gold':float(fh is not None and (first is None or fh<first)),'returned_recall':len(gold&set(full))/len(gold),'returned_precision':len(gold&set(full))/len(full) if full else 0,'returned_false_activations':len(set(full)-gold)}
        for g in (q['task'],q['task']+'/'+q['view'],q['task']+'/family/'+q['family']): groups[g].append(m)
    print(json.dumps({'split':args.split,'k':args.k,'queries':len(qs),'missing_predictions':len(qs)-len(preds),'groups':{g:dict(n=len(ms),**{k:round(statistics.mean(m[k] for m in ms),6) for k in ms[0]}) for g,ms in sorted(groups.items())}},indent=2))
if __name__=='__main__': main()
