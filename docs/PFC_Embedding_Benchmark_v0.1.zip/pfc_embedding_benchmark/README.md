# PFC pseudo-AOTD embedding retrieval benchmark — v0.1

Synthetic, deliberately dense software-engineering action memory. This is a retrieval benchmark, not an AFM training corpus and not a language decomposition exercise. The policy values are invented for an imaginary project, not recommended engineering or compliance requirements. No embedding model has been run.

## Architecture being tested

One flat entity registry. An entity is represented by a concept and zero or more decorators; A and T are roles determined only by a directed edge. Operations are independently represented by an operation concept, exact phase, exact modality, and contextual text. Graph connectivity is separate from the embeddings. There is no conceptual hierarchy, no reverse traversal by default, and no custom weight training. A curated alternate direction is a separately authored edge with the same source-rule provenance.

## Files

- `entities.jsonl`: stable IDs, concept, decorator list, contextual text. Shared by A and T.
- `operations.jsonl`: stable IDs, concept, signed phase, modality, contextual text. `+` = 1, `++` = 2, `-` = -1 in this fixture. Exact modality distinguishes not-required from prohibited; required from permitted. Numeric requirements and conditional qualifiers remain in authoritative constraint text.
- `relationships.jsonl`: directed source/operation/target IDs and rule provenance. Multiple edges can refer to the same original rule. Deduplicate by `rule_id` for constraint retrieval.
- `constraints.jsonl`: original natural-language directive, canonical edge, separately authored alternate edge(s), phase, modality. Return the exact directive rather than infer its content from similarity.
- `queries_dev.jsonl`, `queries_test.jsonl`: entity, operation-topic, operation-modality, and relationship/constraint queries. Each record has `positive_ids`, `hard_negative_ids`, task and view. `oracle_*` is a privileged structure for isolated embedding experiments; never expose qrels, source rule ID or oracle fields to the model in the natural-query track. Relationship positives are rule IDs, not edge IDs. Some queries additionally supply edge-level gold (valid directions).
- `paths_dev.jsonl`, `paths_test.jsonl`: isolate forward operation-resonance propagation from an oracle seed. The gold includes both valid branches where the same operation resonates, as well as a different-operation distractor and an incoming-edge distractor. This is path activation, not transitive logical inference.
- `aliases_audit_only.jsonl`: audit aid; do not index or include in prompts.
- `manifest.json`: actual counts and structural validation results.
- `build_dataset.py`: deterministic fixture generator, standard library only. Contains all gold and must not be provided to a tested retrieval agent.
- `score.py`: dependency-free scoring for ranked predictions. No model inference.

## Why this is dense

Each policy family has eight constraints: six scope variants sharing an operation topic and target, plus two additional rules sharing entities but changing operation or target. The corpus mixes positive, negative and strengthened phases, permitted vs prohibited, not-required vs required, closely related scopes, exact numeric conditions, and independently authored directional views. Export and notification families explicitly vary two or three decorators, including overlap and exceptions. Target aliases also query the same entity registry. Path probes contain same-operation branches so an implementation cannot get full credit by returning a single path.

Example: month-end, dashboard, regulatory, provisional, reconciliation and archived reports share transaction consistency but carry different requirements. The month-end report also has an audit-log retention directive: same source, different operation and target. A narrow query should recover the appropriate rule; a broad query should recover every applicable synthetic scope, including opposing modalities.

## Comparison matrix (freeze the encoder)

Use the same pretrained embedding model (e.g. Qwen3-Embedding-0.6B), exact revision, output dimension, normalization and deterministic inference settings across variants. For symmetric graph resonance start with identical encoding conventions for queries and stored items; test instruction-conditioned query encoding separately. Let `norm` mean L2 normalization, `u(x)` a normalized frozen-model embedding, `a` the core concept and `d_i` the decorator text.

| ID | Entity generation | Operation generation |
|---|---|---|
| C0 | Direct contextual: `u(contextual_text)` | `u(contextual_text)` including phase/modality |
| C1 | Additive: `norm(u(a) + lambda * mean_i(u(d_i)))` | `norm(u(o) + mu*u(phase_and_modality_text))` |
| C2 | Contextual blend: `norm((1-lambda)*u(a) + lambda*u(contextual_text))` | same interpolation between concept and contextual operation |
| C3 | Decorator-weighted sum: `norm(u(a) + sum_i(lambda_i*u(d_i)))` | signed phase and modality text as C1; report separately |
| C4 | Role-tagged composition: `u('Entity: ' + a + '; Qualifiers: ' + ...)` | `u('Operation: ' + o + '; Phase: ' + ... + '; Modality: ' + ...)` |
| C5 | Base-only ablation: `u(a)` | `u(o)` |
| R0 | Whole original constraint embedding (not an entity/operation baseline) | Whole original constraint embedding |

When no decorators are present, C1/C3 reduce to the base embedding. When query phase/modality is unspecified, use a neutral operation concept; do not insert a guessed positive phase. Never use multiplication by a negative scalar as the default negation representation: opposite requirements should be discoverable under neutral operation queries. If testing it, treat it as a separate ablation. For reverse-direction operation variants with distinctive wording, C0 preserves `contextual_text`; C1/C3 can deliberately drop such nuance, which is part of what is being tested. Phase/modality and authoritative rule text always survive outside the embedding.

Compare lambda/mu values 0.25, 0.5, 0.75, 1 on dev only. C2 at lambda=1 is exactly C0. For C3, compare equal per-decorator weight with total decorator weight held fixed (C1) to detect dilution/overweighting as decorator count grows. Do not train an encoder. Choose a small fixed set of variants before opening test labels.

## Evaluation protocol

1. Entity isolation: rank the full shared entity population using cosine similarity, separately report exact decorated entity, base/broad, target-origin aliases, and partial-decorator queries. Exact-scope aliases are intended to denote the named fixture scope, not all its descendants; the explicit `all ... variants` queries test broader matching. There is no hierarchy in the implementation.
2. Operation isolation: rank all operations. Neutral queries should surface all relevant phases, including negatives. Exact-modality queries measure whether embeddings separate phase and modality, not whether different modalities are logically incompatible. Evaluate raw embedding rankings first; report any exact metadata gate as a separate variant, never as proof that embeddings distinguish polarity.
3. Constraint retrieval: run R0 with natural query text and all constraint texts. For C0–C5, start with oracle structured queries to isolate the numerical method, then repeat using a fixed coding-agent/LLM decomposition of natural queries; report separately. Seed all supplied terms against their shared registries. Compare same-role and role-agnostic initial activation only as explicitly labeled variants; no assumed reverse edge. For a simple single-edge scoring baseline, record A/O/T similarities separately and compare min/product/weighted sum on dev; do not conflate with resonance traversal. Aggregate canonical and alternate edges into unique rule IDs. For directional queries also score returned edge IDs against `positive_edge_ids` as a separate diagnostic (where present).
4. Propagation: use `paths_*.jsonl` with the supplied seed, neutral operation and no target. Evaluate outgoing edges via O resonance, stop below threshold, retain both resonating branches. Never follow incoming edges automatically. Keep cycle protection and explicit safety cap separate from semantics. Return actual activated edges and paths, not invented inferred constraints.
5. Tune thresholds, dimensions (e.g. 256, 512, 1024 if encoder supports them), weights, and candidate caps only on dev; freeze for test. First establish exact exhaustive scores; test ANN recall and latency separately. Measure embedding and propagation latency independently; count initial candidates, edges evaluated, edges surviving and edges returned.

## Metrics and prediction interface

Primary metrics: recall@5/10/20, MRR, precision@k, full gold coverage at k, hard-negative exposure at k, hard-negative outranking of the best gold, plus path edge recall/precision. Report results by task, query view and family; narrow and broad queries must be shown separately. Broad operation queries can have more than ten gold items, so do not interpret recall@10 as a complete-retrieval metric. Threshold mode should report complete gold recall and false activations across all returned items (in addition to fixed top-k). The scorer treats declared gold as the expected closed-world fixture answers, other corpus entries as non-gold; explicit hard negatives are the targeted distractors. No graded partial relevance is claimed.

Predictions: JSONL, one row per query: `{"id":"<query id>","ranked_ids":["<corpus id>","..."]}`. For path cases use ranked relationship edge IDs; output only activated edges, even if empty. Run `python score.py --split dev --predictions predictions.jsonl --k 10`; use `--split test` only after tuning. Missing predictions are counted as empty, duplicate IDs rejected, unknown IDs rejected. Score script reports per-task/view and family. Provide separate prediction files for each composition and query track.

## Limitations

Synthetic, hand-authored seed policies with templated paraphrases; dense *local neighborhoods*, not a production-scale latency corpus. No real insrc project data, external annotation, empirical embeddings, measured thresholds, or human inter-annotator agreement. Family-held-out query labels and exact cross-split query-text checks reduce leakage; corpus and its embedding representations are intentionally shared (retrieval, not unseen-document training). Some operation concepts can recur across families. Oracle queries use canonical components to isolate representation, so they are not an end-to-end test. Some contextual aliases may be ambiguous outside the closed fixture. The generator is inspectable, and all labels should be reviewed before treating test results as definitive. For later production evaluation, collect real agent decision contexts and user-validated memory applicability independently of this fixture.
